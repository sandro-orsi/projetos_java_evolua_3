package exerciciosJavaEvolua;

import java.util.*;

public class Exercicio_15{

    public static void main(String[] args) {
             int n1, n2, soma ;          
             Scanner captura = new Scanner( System.in ) ;  
          
             System.out.println( "Digite um número: " ) ;  
             n1 = captura.nextInt( ) ;  
			 
             System.out.println( "Digite outro número: " ) ;  
             n2 = captura.nextInt( ) ;  
			 
             soma = n1 + n2 ;  
			 
                 System.out.println( "A soma é: " + soma ) ;  
             }  
      }  
  