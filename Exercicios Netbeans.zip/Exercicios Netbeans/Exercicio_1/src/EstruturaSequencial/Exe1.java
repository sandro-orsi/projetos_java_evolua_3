//Faça um programa para ler dois valores inteiros
//e depois mostrar na tela
// para somar 10 + 30 e trazer uma soma

package EstruturaSequencial;

import java.util.Scanner;

public class Exe1 {
    public static void main(String[] args) {
		Scanner sc =  new  Scanner(System.in);
		int a, b ,soma;
                a = 10;
                b = 30;
		soma =  a+b;
            System.out.println("Soma = " + soma);;
	}
}
