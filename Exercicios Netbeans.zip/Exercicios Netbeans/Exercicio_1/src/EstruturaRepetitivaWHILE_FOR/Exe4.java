/*
For em Array 
 */
package EstruturaRepetitivaWHILE_FOR;

import java.util.Scanner;

public class Exe4 {
    public static void main(String[] args) {
        
        //For em ArrayList
        int num[] = {1,2,3,4,6,4};
        for (int i : num) {
            System.out.println("Numero: "+i);
        }
    }
}